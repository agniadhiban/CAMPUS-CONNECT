from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from sqlalchemy import or_

from campusconnect.announcements import announcements_bp
from campusconnect.announcements.forms import AnnouncementForm, AnonymousTipForm
from campusconnect.extensions import db
from campusconnect.models import Announcement, AnonymousTip, College
from campusconnect.decorators import permission_required


@announcements_bp.route("/")
@login_required
def list_announcements():
    if current_user.is_master_admin:
        query = Announcement.query
    else:
        # Your own college's announcements, plus any global (college_id is None) ones.
        query = Announcement.query.filter(
            or_(Announcement.college_id == current_user.college_id, Announcement.college_id.is_(None))
        )
    announcements = query.order_by(Announcement.is_pinned.desc(), Announcement.created_at.desc()).all()
    return render_template("announcements/list.html", announcements=announcements)


@announcements_bp.route("/new", methods=["GET", "POST"])
@login_required
@permission_required("manage_announcements")
def new_announcement():
    form = AnnouncementForm()
    colleges = None
    if current_user.is_master_admin:
        colleges = College.query.order_by(College.name.asc()).all()
        form.college_id.choices = [(0, "All colleges (global)")] + [(c.id, c.name) for c in colleges]
    else:
        # This field isn't shown to a regular admin at all — their posts are
        # always scoped to their own college automatically — so it needs an
        # empty-but-valid choice list and no strict choice-matching, or
        # WTForms would reject/crash on a field with nothing submitted for it.
        form.college_id.choices = []
        form.college_id.validate_choice = False

    if form.validate_on_submit():
        if current_user.is_master_admin:
            target_college_id = form.college_id.data or None
            if target_college_id == 0:
                target_college_id = None
        else:
            target_college_id = current_user.college_id  # a regular admin can never post outside their own college

        announcement = Announcement(
            title=form.title.data.strip(),
            body=form.body.data.strip(),
            is_pinned=form.is_pinned.data,
            posted_by_id=current_user.id,
            college_id=target_college_id,
        )
        db.session.add(announcement)
        db.session.commit()
        flash("Announcement posted.", "success")
        return redirect(url_for("announcements.list_announcements"))
    return render_template("announcements/new.html", form=form, colleges=colleges)


@announcements_bp.route("/tip", methods=["GET", "POST"])
@login_required
def new_tip():
    """Fully anonymous — we don't store who submitted it, by design. We do
    keep which college it came from, so that college's admins (and only
    them) can review it."""
    if not current_user.is_student:
        return redirect(url_for("main.dashboard"))

    form = AnonymousTipForm()
    if form.validate_on_submit():
        tip = AnonymousTip(
            subject=form.subject.data.strip(),
            body=form.body.data.strip(),
            college_id=current_user.college_id,
        )
        db.session.add(tip)
        db.session.commit()
        flash("Sent anonymously. Thank you for speaking up.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("announcements/new_tip.html", form=form)


@announcements_bp.route("/tips")
@login_required
@permission_required("manage_announcements")
def list_tips():
    colleges = None
    college_filter = None
    if current_user.is_master_admin:
        query = AnonymousTip.query
        colleges = College.query.order_by(College.name.asc()).all()
        college_filter = request.args.get("college", type=int)
        if college_filter:
            query = query.filter_by(college_id=college_filter)
    else:
        query = AnonymousTip.query.filter_by(college_id=current_user.college_id)
    tips = query.order_by(AnonymousTip.created_at.desc()).all()
    return render_template("announcements/tips_list.html", tips=tips, colleges=colleges, college_filter=college_filter)


@announcements_bp.route("/tips/<public_id>/close", methods=["POST"])
@login_required
@permission_required("manage_announcements")
def close_tip(public_id):
    tip = AnonymousTip.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.can_access_college(tip.college_id):
        abort(403)
    tip.status = "closed"
    db.session.commit()
    flash("Tip marked closed.", "success")
    return redirect(url_for("announcements.list_tips"))
