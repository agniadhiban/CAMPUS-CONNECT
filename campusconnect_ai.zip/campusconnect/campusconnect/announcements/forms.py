from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, BooleanField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, Optional


class AnnouncementForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    body = TextAreaField("Message", validators=[DataRequired(), Length(max=3000)])
    # Only shown/used for the Master Admin — a regular admin's announcement is
    # always scoped to their own college automatically. 0 = "All colleges".
    college_id = SelectField("Audience", coerce=int, validators=[Optional()])
    is_pinned = BooleanField("Pin to top")
    submit = SubmitField("Post announcement")


class AnonymousTipForm(FlaskForm):
    subject = StringField("Subject", validators=[DataRequired(), Length(max=150)])
    body = TextAreaField("Details", validators=[DataRequired(), Length(max=3000)])
    submit = SubmitField("Send anonymously")
