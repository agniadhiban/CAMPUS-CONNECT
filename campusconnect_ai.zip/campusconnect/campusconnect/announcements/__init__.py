from flask import Blueprint

announcements_bp = Blueprint("announcements", __name__, url_prefix="/announcements")

from campusconnect.announcements import routes  # noqa: E402,F401
