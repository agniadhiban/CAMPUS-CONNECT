"""
A small, hand-built set of line icons for CampusConnect.

Built from basic SVG primitives only (circle/rect/line/polyline/polygon —
no bezier paths) so every icon is guaranteed to render correctly without
needing a browser to preview. Exposed to templates as a Jinja global:

    {{ icon('alert') }}
    {{ icon('alert', 'w-4 h-4 text-gold-400') }}
"""
from markupsafe import Markup

_ICONS = {
    "alert": """
        <polygon points="12,3 22,20 2,20" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
        <line x1="12" y1="9" x2="12" y2="14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <circle cx="12" cy="17.3" r="1" fill="currentColor" stroke="none"/>
    """,
    "clipboard": """
        <rect x="5" y="4" width="14" height="17" rx="1" fill="none" stroke="currentColor" stroke-width="2"/>
        <rect x="9" y="2" width="6" height="4" rx="1" fill="none" stroke="currentColor" stroke-width="2"/>
        <line x1="8" y1="11" x2="16" y2="11" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <line x1="8" y1="15" x2="13" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    """,
    "box": """
        <rect x="4" y="9" width="16" height="11" rx="1" fill="none" stroke="currentColor" stroke-width="2"/>
        <polyline points="4,9 12,4 20,9" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
        <line x1="12" y1="9" x2="12" y2="20" stroke="currentColor" stroke-width="2"/>
    """,
    "incognito": """
        <line x1="3" y1="9" x2="21" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <circle cx="7.5" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="2"/>
        <circle cx="16.5" cy="9" r="3" fill="none" stroke="currentColor" stroke-width="2"/>
        <line x1="10.5" y1="9" x2="13.5" y2="9" stroke="currentColor" stroke-width="2"/>
    """,
    "pin": """
        <circle cx="12" cy="8" r="5" fill="none" stroke="currentColor" stroke-width="2"/>
        <line x1="12" y1="13" x2="12" y2="21" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    """,
    "chart": """
        <line x1="4" y1="20" x2="20" y2="20" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <rect x="6" y="12" width="3" height="8" fill="currentColor"/>
        <rect x="11" y="7" width="3" height="13" fill="currentColor"/>
        <rect x="16" y="15" width="3" height="5" fill="currentColor"/>
    """,
    "shield": """
        <polygon points="12,3 20,6 20,12 12,21 4,12 4,6" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
    """,
    "users": """
        <circle cx="12" cy="8" r="4" fill="none" stroke="currentColor" stroke-width="2"/>
        <polyline points="4,21 4,19 8,15 16,15 20,19 20,21" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
    """,
    "check": """
        <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/>
        <polyline points="8,12.5 11,15.5 16,9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    """,
    "clock": """
        <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/>
        <line x1="12" y1="7" x2="12" y2="12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <line x1="12" y1="12" x2="15.5" y2="14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    """,
    "x-circle": """
        <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"/>
        <line x1="9" y1="9" x2="15" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        <line x1="15" y1="9" x2="9" y2="15" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
    """,
    "mappin": """
        <circle cx="12" cy="10" r="3" fill="none" stroke="currentColor" stroke-width="2"/>
        <polyline points="7,10 12,21 17,10" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>
    """,
}


def icon(name, cls="w-5 h-5"):
    body = _ICONS.get(name, "")
    return Markup(f'<svg class="{cls}" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">{body}</svg>')
