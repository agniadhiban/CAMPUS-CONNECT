import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
load_dotenv(os.path.join(basedir, ".env"))


class Config:
    """
    Runs as a local-development app by default (SQLite, debug mode on,
    insecure-cookie settings suited to plain http://127.0.0.1).

    The same code can also run on a free hosting service like Render:
    Render automatically sets an env var called RENDER=true for every
    service it runs, so this config detects that and switches on
    production-safe settings automatically — no manual toggle needed.
    """

    IS_HOSTED = os.environ.get("RENDER") == "true"

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    # Local dev: SQLite file next to the project. On a host that provides
    # DATABASE_URL (e.g. a managed Postgres add-on), that takes priority.
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", "sqlite:///" + os.path.join(basedir, "campusconnect.db")
    )
    # Some hosts hand out "postgres://" which SQLAlchemy 2.x no longer accepts;
    # normalize it to "postgresql://" automatically.
    if SQLALCHEMY_DATABASE_URI.startswith("postgres://"):
        SQLALCHEMY_DATABASE_URI = SQLALCHEMY_DATABASE_URI.replace("postgres://", "postgresql://", 1)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    DEBUG = not IS_HOSTED
    TESTING = False

    # Secure cookies only make sense over https, which a real host provides
    # but http://127.0.0.1 does not.
    SESSION_COOKIE_SECURE = IS_HOSTED
    REMEMBER_COOKIE_SECURE = IS_HOSTED

    MASTER_ADMIN_EMAIL = os.environ.get("MASTER_ADMIN_EMAIL", "Agni.adhiban@gmail.com")
    MASTER_ADMIN_USERNAME = os.environ.get("MASTER_ADMIN_USERNAME", "Adhiban")
    MASTER_ADMIN_PASSWORD = os.environ.get("MASTER_ADMIN_PASSWORD", "ChangeMe123!")
    MASTER_ADMIN_NAME = os.environ.get("MASTER_ADMIN_NAME", "Adhiban")

    # Times are stored in UTC. This shifts what's DISPLAYED to local time.
    # 330 = India (UTC+5:30). Change via the DISPLAY_UTC_OFFSET_MINUTES env var.
    DISPLAY_UTC_OFFSET_MINUTES = int(os.environ.get("DISPLAY_UTC_OFFSET_MINUTES", "330"))

    # --- Duplicate-detection / priority-escalation tuning ---
    # Two complaints are considered "the same issue" if they share a category,
    # their locations look similar enough, and their description text is similar
    # enough (see campusconnect/complaints/utils.py for the matching logic).
    DUPLICATE_TEXT_SIMILARITY_THRESHOLD = 0.55   # 0-1, higher = stricter match
    DUPLICATE_LOCATION_SIMILARITY_THRESHOLD = 0.6
    DUPLICATE_TIME_WINDOW_HOURS = 72             # only compare against recent complaints

    # Report-count thresholds that bump priority up a level.
    # 1 report = low, 2-3 = medium, 4-6 = high, 7+ = critical
    PRIORITY_THRESHOLDS = {
        "low": 1,
        "medium": 2,
        "high": 4,
        "critical": 7,
    }

    # --- Lost & Found matching (same idea as duplicate-detection above) ---
    # A "lost" post and a "found" post are shown to each other as a possible
    # match when their item names look similar enough (name carries most of
    # the signal - descriptions are often left blank) and, combined with the
    # description, clear this overall bar.
    LOSTFOUND_NAME_SIMILARITY_THRESHOLD = 0.6   # 0-1, name alone must clear this first
    LOSTFOUND_MATCH_THRESHOLD = 0.5             # 0-1, combined name+description score

    UPLOAD_FOLDER = os.path.join(basedir, "static", "uploads")
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 MB max upload (photos for lost&found / complaints)
