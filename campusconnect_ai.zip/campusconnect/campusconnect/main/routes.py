from flask import render_template, redirect, url_for
from flask_login import login_required, current_user
from sqlalchemy import func, or_

from campusconnect.main import main_bp
from campusconnect.extensions import db
from campusconnect.models import (
    Complaint, ComplaintStatus, ComplaintPriority,
    SOSAlert, SOSStatus, LostFoundItem, Announcement, User, Role, College,
)


@main_bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("auth.login"))


@main_bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.is_student:
        return _student_dashboard()
    return _staff_dashboard()


def _student_dashboard():
    my_complaints = (
        Complaint.query.filter_by(reporter_id=current_user.id)
        .order_by(Complaint.created_at.desc())
        .limit(5)
        .all()
    )
    active_sos = (
        SOSAlert.query.filter_by(student_id=current_user.id)
        .filter(SOSAlert.status != SOSStatus.RESOLVED)
        .order_by(SOSAlert.created_at.desc())
        .first()
    )
    # Your own college's announcements, plus any global ones.
    announcements = (
        Announcement.query.filter(
            or_(Announcement.college_id == current_user.college_id, Announcement.college_id.is_(None))
        )
        .order_by(Announcement.is_pinned.desc(), Announcement.created_at.desc())
        .limit(5)
        .all()
    )
    recent_found_items = (
        LostFoundItem.query.filter_by(item_type="found", is_resolved=False, college_id=current_user.college_id)
        .order_by(LostFoundItem.created_at.desc())
        .limit(4)
        .all()
    )

    return render_template(
        "main/student_dashboard.html",
        my_complaints=my_complaints,
        active_sos=active_sos,
        announcements=announcements,
        recent_found_items=recent_found_items,
    )


def _staff_dashboard():
    can_see_complaints = current_user.has_permission("manage_complaints")
    can_see_sos = current_user.has_permission("manage_sos")
    can_see_lostfound = current_user.has_permission("manage_lostfound")
    can_see_analytics = current_user.has_permission("view_analytics")
    is_master = current_user.is_master_admin

    stats = {}
    priority_queue = []
    active_sos_alerts = []
    unresolved_items_count = 0

    if can_see_complaints:
        complaint_scope = Complaint.query if is_master else Complaint.query.filter_by(college_id=current_user.college_id)
        stats["open_complaints"] = complaint_scope.filter_by(status=ComplaintStatus.OPEN).count()
        stats["in_progress"] = complaint_scope.filter_by(status=ComplaintStatus.IN_PROGRESS).count()
        stats["resolved_total"] = complaint_scope.filter_by(status=ComplaintStatus.RESOLVED).count()
        stats["critical_open"] = complaint_scope.filter_by(
            status=ComplaintStatus.OPEN, priority=ComplaintPriority.CRITICAL
        ).count()

        # Priority queue: open complaints, most severe & most-reported first.
        priority_rank = {p: i for i, p in enumerate(ComplaintPriority.ORDER)}
        open_complaints = complaint_scope.filter(
            Complaint.status.in_([ComplaintStatus.OPEN, ComplaintStatus.IN_PROGRESS])
        ).all()
        priority_queue = sorted(
            open_complaints,
            key=lambda c: (-priority_rank.get(c.priority, 0), -c.report_count),
        )[:8]

    if can_see_sos:
        sos_scope = SOSAlert.query if is_master else SOSAlert.query.filter_by(college_id=current_user.college_id)
        active_sos_alerts = (
            sos_scope.filter(SOSAlert.status != SOSStatus.RESOLVED)
            .order_by(SOSAlert.created_at.desc())
            .all()
        )

    if can_see_lostfound:
        lf_scope = LostFoundItem.query if is_master else LostFoundItem.query.filter_by(college_id=current_user.college_id)
        unresolved_items_count = lf_scope.filter_by(is_resolved=False).count()

    student_count = User.query.filter_by(role=Role.STUDENT).count() if is_master else None
    admin_count = User.query.filter_by(role=Role.ADMIN).count() if is_master else None
    college_count = College.query.count() if is_master else None

    return render_template(
        "main/staff_dashboard.html",
        stats=stats,
        priority_queue=priority_queue,
        active_sos_alerts=active_sos_alerts,
        unresolved_items_count=unresolved_items_count,
        can_see_complaints=can_see_complaints,
        can_see_sos=can_see_sos,
        can_see_lostfound=can_see_lostfound,
        can_see_analytics=can_see_analytics,
        student_count=student_count,
        admin_count=admin_count,
        college_count=college_count,
    )


@main_bp.route("/analytics")
@login_required
def analytics():
    if not current_user.has_permission("view_analytics"):
        return redirect(url_for("main.dashboard"))

    base_query = db.session.query(Complaint)
    if not current_user.is_master_admin:
        base_query = base_query.filter(Complaint.college_id == current_user.college_id)
    scoped_ids = base_query.with_entities(Complaint.id).subquery()

    by_category = (
        db.session.query(Complaint.category, func.count(Complaint.id))
        .filter(Complaint.id.in_(scoped_ids))
        .group_by(Complaint.category)
        .all()
    )
    by_status = (
        db.session.query(Complaint.status, func.count(Complaint.id))
        .filter(Complaint.id.in_(scoped_ids))
        .group_by(Complaint.status)
        .all()
    )
    by_priority = (
        db.session.query(Complaint.priority, func.count(Complaint.id))
        .filter(Complaint.id.in_(scoped_ids))
        .group_by(Complaint.priority)
        .all()
    )
    top_locations = (
        db.session.query(Complaint.location, func.count(Complaint.id).label("cnt"))
        .filter(Complaint.id.in_(scoped_ids))
        .group_by(Complaint.location)
        .order_by(func.count(Complaint.id).desc())
        .limit(5)
        .all()
    )

    return render_template(
        "main/analytics.html",
        by_category=by_category,
        by_status=by_status,
        by_priority=by_priority,
        top_locations=top_locations,
    )
