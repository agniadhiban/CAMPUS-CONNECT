import uuid
from datetime import datetime, timezone

from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

from campusconnect.extensions import db


def now_utc():
    return datetime.now(timezone.utc)


def gen_uuid():
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Colleges (institutions) — multi-tenant support
# ---------------------------------------------------------------------------
class College(db.Model):
    """
    One row per institution using CampusConnect. Every student and regular
    admin belongs to exactly one college and only ever sees that college's
    data. The Master Admin belongs to no single college (college_id is None
    on their own User row) and can see across all of them.
    """
    __tablename__ = "colleges"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    name = db.Column(db.String(150), unique=True, nullable=False)
    code = db.Column(db.String(20), unique=True, nullable=True)  # short code, e.g. "MIT" — optional
    address = db.Column(db.String(255))

    is_active = db.Column(db.Boolean, default=True)  # inactive colleges can't be picked for new signups
    created_at = db.Column(db.DateTime, default=now_utc)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    users = db.relationship("User", backref="college", lazy="dynamic", foreign_keys="User.college_id")

    def __repr__(self):
        return f"<College {self.name}>"


# ---------------------------------------------------------------------------
# Users & roles
# ---------------------------------------------------------------------------
class Role:
    MASTER_ADMIN = "master_admin"
    ADMIN = "admin"
    STUDENT = "student"

    ALL = [MASTER_ADMIN, ADMIN, STUDENT]


# Fine-grained permissions a Master Admin can grant/revoke per Admin account.
ADMIN_PERMISSIONS = [
    ("manage_complaints", "Manage & resolve complaints"),
    ("manage_lostfound", "Manage lost & found items"),
    ("manage_sos", "Respond to SOS alerts"),
    ("manage_announcements", "Post announcements"),
    ("view_analytics", "View analytics dashboard"),
]


class User(UserMixin, db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)

    role = db.Column(db.String(20), nullable=False, default=Role.STUDENT)
    department = db.Column(db.String(120))
    student_id = db.Column(db.String(40))  # college roll no / ID, students only
    phone = db.Column(db.String(30))

    # Every student and admin belongs to a college; the Master Admin doesn't
    # (None = sees/manages across every college).
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)

    # Comma-separated permission keys from ADMIN_PERMISSIONS, only meaningful for role=admin.
    # Master admin implicitly has every permission.
    permissions = db.Column(db.String(255), default="")

    is_active_account = db.Column(db.Boolean, default=True)  # allows master admin to disable an admin/student
    created_at = db.Column(db.DateTime, default=now_utc)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    complaints = db.relationship("Complaint", foreign_keys="Complaint.reporter_id", backref="reporter", lazy="dynamic")
    sos_alerts = db.relationship("SOSAlert", foreign_keys="SOSAlert.student_id", backref="student", lazy="dynamic")

    # --- password helpers ---
    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    # --- role helpers ---
    @property
    def is_master_admin(self):
        return self.role == Role.MASTER_ADMIN

    @property
    def is_admin(self):
        return self.role == Role.ADMIN

    @property
    def is_student(self):
        return self.role == Role.STUDENT

    @property
    def is_staff(self):
        """True for anyone with elevated (admin or master admin) access."""
        return self.role in (Role.ADMIN, Role.MASTER_ADMIN)

    def has_permission(self, key):
        if self.is_master_admin:
            return True
        if not self.is_admin:
            return False
        return key in (self.permissions or "").split(",")

    def can_access_college(self, college_id):
        """True if this user is allowed to see data belonging to the given college.
        The Master Admin can access every college; everyone else only their own."""
        if self.is_master_admin:
            return True
        return self.college_id is not None and self.college_id == college_id

    def get_id(self):
        # Flask-Login requires a stable string id; use the real PK.
        return str(self.id)

    # active is used by UserMixin/Flask-Login to block disabled accounts from logging in
    @property
    def is_active(self):
        return self.is_active_account

    def __repr__(self):
        return f"<User {self.username} ({self.role})>"


# ---------------------------------------------------------------------------
# Complaints (issue reporting) with duplicate-detection priority escalation
# ---------------------------------------------------------------------------
class ComplaintStatus:
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    REJECTED = "rejected"

    ALL = [OPEN, IN_PROGRESS, RESOLVED, REJECTED]


class ComplaintPriority:
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

    ORDER = [LOW, MEDIUM, HIGH, CRITICAL]  # index = severity rank


class ComplaintCategory:
    ELECTRICAL = "electrical"
    PLUMBING = "plumbing"
    WIFI_IT = "wifi_it"
    CLEANLINESS = "cleanliness"
    FURNITURE = "furniture"
    SECURITY = "security"
    HOSTEL = "hostel"
    OTHER = "other"

    ALL = [ELECTRICAL, PLUMBING, WIFI_IT, CLEANLINESS, FURNITURE, SECURITY, HOSTEL, OTHER]


class Complaint(db.Model):
    __tablename__ = "complaints"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(30), nullable=False, default=ComplaintCategory.OTHER)
    location = db.Column(db.String(150), nullable=False)

    status = db.Column(db.String(20), nullable=False, default=ComplaintStatus.OPEN)
    priority = db.Column(db.String(20), nullable=False, default=ComplaintPriority.LOW)

    is_anonymous = db.Column(db.Boolean, default=False)
    reporter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)  # null-safe even if reporter deleted
    photo_filename = db.Column(db.String(255))

    # Which college this complaint belongs to (copied from the reporter's
    # college at creation time). Every complaint query is scoped by this.
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)

    # --- duplicate-detection / grouping ---
    # All complaints describing the same real-world issue share a group_id.
    # report_count on the group "root" reflects how many students reported it;
    # that count is what drives priority escalation.
    group_id = db.Column(db.String(36), index=True)  # shared across duplicates; new complaint = its own public_id
    report_count = db.Column(db.Integer, default=1)  # only meaningful on the group's first/root complaint

    assigned_admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    resolution_note = db.Column(db.Text)

    created_at = db.Column(db.DateTime, default=now_utc, index=True)
    updated_at = db.Column(db.DateTime, default=now_utc, onupdate=now_utc)
    resolved_at = db.Column(db.DateTime)

    assigned_admin = db.relationship("User", foreign_keys=[assigned_admin_id])
    updates = db.relationship("ComplaintUpdate", backref="complaint", lazy="dynamic",
                               cascade="all, delete-orphan", order_by="ComplaintUpdate.created_at")

    def display_reporter_name(self):
        if self.is_anonymous:
            return "Anonymous"
        return self.reporter.full_name if self.reporter else "Unknown"


class ComplaintUpdate(db.Model):
    """Timeline entries: status changes, admin notes, duplicate reports merged in."""
    __tablename__ = "complaint_updates"

    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey("complaints.id"), nullable=False)
    author_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    note = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=now_utc)

    author = db.relationship("User", foreign_keys=[author_id])


# ---------------------------------------------------------------------------
# Lost & Found
# ---------------------------------------------------------------------------
class LostFoundType:
    LOST = "lost"
    FOUND = "found"


class LostFoundItem(db.Model):
    __tablename__ = "lost_found_items"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    item_type = db.Column(db.String(10), nullable=False)  # lost | found
    item_name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    location = db.Column(db.String(150))
    photo_filename = db.Column(db.String(255))

    reported_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    contact_info = db.Column(db.String(150))  # optional override contact shown to others
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)

    is_resolved = db.Column(db.Boolean, default=False)  # claimed / returned to owner
    created_at = db.Column(db.DateTime, default=now_utc, index=True)
    resolved_at = db.Column(db.DateTime)

    reported_by = db.relationship("User", foreign_keys=[reported_by_id])

    def display_reporter_name(self, viewer):
        """Lost & found posts never show who posted them, except to the
        Master Admin (kept for accountability if something needs following up).
        Everyone else - other students, other admins, even the poster's own
        college admin - sees "Anonymous". The Contact box is unaffected, so
        people can still get in touch to return an item."""
        if viewer is not None and getattr(viewer, "is_master_admin", False):
            return self.reported_by.full_name if self.reported_by else "Unknown"
        return "Anonymous"

    @property
    def is_global(self):
        """True if this post has no single college (shown on every college's board)."""
        return self.college_id is None


# ---------------------------------------------------------------------------
# SOS Emergency Alerts
# ---------------------------------------------------------------------------
class SOSUrgency:
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"

    ALL = [MODERATE, HIGH, CRITICAL]


class SOSStatus:
    ACTIVE = "active"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"


class SOSAlert(db.Model):
    __tablename__ = "sos_alerts"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    student_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    urgency = db.Column(db.String(20), nullable=False, default=SOSUrgency.HIGH)
    message = db.Column(db.Text)
    location_text = db.Column(db.String(200))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)

    status = db.Column(db.String(20), nullable=False, default=SOSStatus.ACTIVE)
    handled_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)

    created_at = db.Column(db.DateTime, default=now_utc, index=True)
    location_updated_at = db.Column(db.DateTime)  # bumped every time a live position update arrives
    acknowledged_at = db.Column(db.DateTime)
    resolved_at = db.Column(db.DateTime)

    handled_by = db.relationship("User", foreign_keys=[handled_by_id])


# ---------------------------------------------------------------------------
# Announcements (admin -> students broadcast; supports anonymous student tips)
# ---------------------------------------------------------------------------
class Announcement(db.Model):
    __tablename__ = "announcements"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    title = db.Column(db.String(150), nullable=False)
    body = db.Column(db.Text, nullable=False)
    posted_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    is_pinned = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=now_utc, index=True)

    # None = visible to every college (only the Master Admin can post these).
    # Set = visible only to that one college.
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)

    posted_by = db.relationship("User", foreign_keys=[posted_by_id])


class AnonymousTip(db.Model):
    """A student -> admin anonymous report channel, separate from named complaints.
    We keep which college it came from (so that college's admins can review it)
    but never store who sent it."""
    __tablename__ = "anonymous_tips"

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(36), unique=True, default=gen_uuid, nullable=False)

    subject = db.Column(db.String(150), nullable=False)
    body = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default="new")  # new | reviewed | closed
    created_at = db.Column(db.DateTime, default=now_utc, index=True)
    college_id = db.Column(db.Integer, db.ForeignKey("colleges.id"), nullable=True, index=True)
