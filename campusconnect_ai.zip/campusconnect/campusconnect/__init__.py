import os
from flask import Flask

from campusconnect.config import Config
from campusconnect.extensions import db, login_manager, csrf


def create_app(config_class=Config):
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    from campusconnect.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # --- Blueprints ---
    from campusconnect.auth import auth_bp
    from campusconnect.main import main_bp
    from campusconnect.complaints import complaints_bp
    from campusconnect.lostfound import lostfound_bp
    from campusconnect.sos import sos_bp
    from campusconnect.admin import admin_bp
    from campusconnect.announcements import announcements_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(complaints_bp)
    app.register_blueprint(lostfound_bp)
    app.register_blueprint(sos_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(announcements_bp)

    # --- template globals / filters ---
    from campusconnect.models import ComplaintPriority, ComplaintStatus, Role
    from campusconnect.icons import icon

    @app.context_processor
    def inject_globals():
        return dict(
            ComplaintPriority=ComplaintPriority,
            ComplaintStatus=ComplaintStatus,
            Role=Role,
        )

    app.jinja_env.globals["icon"] = icon

    @app.template_filter("dt")
    def format_datetime(value, fmt="%d %b %Y, %I:%M %p"):
        """Times are stored in UTC; show them in local time (see
        DISPLAY_UTC_OFFSET_MINUTES in config.py)."""
        if not value:
            return ""
        from datetime import timedelta, timezone
        if value.tzinfo is not None:
            value = value.astimezone(timezone.utc).replace(tzinfo=None)
        return (value + timedelta(minutes=app.config["DISPLAY_UTC_OFFSET_MINUTES"])).strftime(fmt)

    @app.template_filter("iso_utc")
    def iso_utc(value):
        """UTC timestamp in a form browsers can parse, e.g. for '12s ago' labels."""
        if not value:
            return ""
        if value.tzinfo is not None:
            from datetime import timezone
            value = value.astimezone(timezone.utc).replace(tzinfo=None)
        return value.isoformat() + "Z"

    # --- friendly error pages instead of raw Werkzeug/Flask error dumps ---
    from flask import render_template

    @app.errorhandler(400)
    def bad_request(e):
        return render_template("errors/400.html"), 400

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()  # in case the error left a transaction half-done
        return render_template("errors/500.html"), 500

    with app.app_context():
        db.create_all()
        _ensure_master_admin(app)

    return app


def _ensure_master_admin(app):
    """
    Create the Master Admin account automatically if one doesn't exist yet.

    This runs every time the app starts (locally via run.py/run.bat, or on a
    host like Render). It's a no-op if a master admin already exists, so it's
    always safe to run. This means a real hosting service — which usually
    gives no shell/terminal access on its free tier — still gets a working
    login without needing anyone to run seed.py by hand.
    """
    from campusconnect.models import User, Role

    if User.query.filter_by(role=Role.MASTER_ADMIN).first():
        return

    master = User(
        full_name=app.config["MASTER_ADMIN_NAME"],
        email=app.config["MASTER_ADMIN_EMAIL"].strip().lower(),
        username=app.config["MASTER_ADMIN_USERNAME"].strip().lower(),
        role=Role.MASTER_ADMIN,
    )
    master.set_password(app.config["MASTER_ADMIN_PASSWORD"])
    db.session.add(master)
    db.session.commit()
