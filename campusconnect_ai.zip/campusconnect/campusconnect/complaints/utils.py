"""
Duplicate-detection & automatic priority-escalation engine.

This is CampusConnect AI's core differentiator: when several students
independently report what looks like the same real-world issue (e.g. three
people all report "AC not working, Room 204" within a couple of days), the
system recognizes it's one issue, groups the reports together, and
automatically raises the priority instead of leaving N identical low-priority
tickets sitting in the admin queue.

How it works (kept intentionally simple & explainable — no external ML
service required, so it works offline and is easy to defend in a viva/demo):

1. When a new complaint comes in, we only compare it against OPEN /
   IN_PROGRESS complaints in the same category, reported within the last
   DUPLICATE_TIME_WINDOW_HOURS.
2. For each candidate, we score similarity on two axes:
     - location similarity (normalized string match)
     - description similarity (normalized string match, using difflib)
   Both must clear their configured thresholds for it to count as a match.
3. On the first match found, the new complaint is merged into that group:
     - it gets the same group_id as the existing "root" complaint
     - the root's report_count is incremented
     - a ComplaintUpdate timeline entry is added noting the merge
     - priority is recalculated from the new report_count
4. If no match is found, the complaint becomes its own group (group_id =
   its own public_id), with report_count = 1 and priority = low.
"""
from flask import current_app

from campusconnect.extensions import db
from campusconnect.matching import text_similarity as _similarity
from campusconnect.models import Complaint, ComplaintStatus, ComplaintPriority, ComplaintUpdate


def priority_for_report_count(report_count):
    """Map a report count to a priority level using configured thresholds."""
    thresholds = current_app.config["PRIORITY_THRESHOLDS"]
    if report_count >= thresholds["critical"]:
        return ComplaintPriority.CRITICAL
    if report_count >= thresholds["high"]:
        return ComplaintPriority.HIGH
    if report_count >= thresholds["medium"]:
        return ComplaintPriority.MEDIUM
    return ComplaintPriority.LOW


def find_duplicate_root(new_complaint):
    """Return the existing 'root' Complaint this new one duplicates, or None."""
    from datetime import datetime, timedelta, timezone

    window_hours = current_app.config["DUPLICATE_TIME_WINDOW_HOURS"]
    cutoff = datetime.now(timezone.utc) - timedelta(hours=window_hours)

    text_threshold = current_app.config["DUPLICATE_TEXT_SIMILARITY_THRESHOLD"]
    loc_threshold = current_app.config["DUPLICATE_LOCATION_SIMILARITY_THRESHOLD"]

    candidates = (
        Complaint.query.filter(
            Complaint.category == new_complaint.category,
            Complaint.college_id == new_complaint.college_id,
            Complaint.status.in_([ComplaintStatus.OPEN, ComplaintStatus.IN_PROGRESS]),
            Complaint.created_at >= cutoff,
            Complaint.id != new_complaint.id,
        )
        .order_by(Complaint.created_at.asc())
        .all()
    )

    best_match = None
    best_score = 0.0

    for candidate in candidates:
        loc_score = _similarity(candidate.location, new_complaint.location)
        if loc_score < loc_threshold:
            continue
        text_score = _similarity(
            f"{candidate.title} {candidate.description}",
            f"{new_complaint.title} {new_complaint.description}",
        )
        if text_score < text_threshold:
            continue

        combined = (loc_score + text_score) / 2
        if combined > best_score:
            best_score = combined
            best_match = candidate

    if best_match is None:
        return None

    # Walk to the group root (the complaint holding the running report_count),
    # in case `best_match` is itself a duplicate that was merged earlier.
    root = best_match
    while root.group_id and root.group_id != root.public_id:
        parent = Complaint.query.filter_by(public_id=root.group_id).first()
        if not parent:
            break
        root = parent
    return root


def process_new_complaint(complaint):
    """
    Call this right after a Complaint is added to the session (before commit).
    Sets group_id / report_count / priority, merging into an existing group
    if a duplicate is detected, and logs a timeline entry either way.
    """
    root = find_duplicate_root(complaint)

    if root is None:
        complaint.group_id = complaint.public_id
        complaint.report_count = 1
        complaint.priority = ComplaintPriority.LOW
        db.session.flush()
        db.session.add(ComplaintUpdate(
            complaint_id=complaint.id,
            author_id=None,
            note="Complaint submitted.",
        ))
        return complaint

    # Merge into the existing group.
    root.report_count = (root.report_count or 1) + 1
    root.priority = priority_for_report_count(root.report_count)
    complaint.group_id = root.public_id
    complaint.report_count = root.report_count
    complaint.priority = root.priority

    db.session.flush()
    db.session.add(ComplaintUpdate(
        complaint_id=root.id,
        author_id=None,
        note=(
            f"Another student reported a matching issue "
            f"(now {root.report_count} reports) — priority raised to "
            f"{root.priority.upper()}."
        ),
    ))
    db.session.add(ComplaintUpdate(
        complaint_id=complaint.id,
        author_id=None,
        note=f"This looks like the same issue as complaint #{root.id} — merged into that group.",
    ))
    return complaint
