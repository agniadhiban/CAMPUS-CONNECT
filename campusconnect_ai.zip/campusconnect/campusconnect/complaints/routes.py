import os
import uuid

from flask import render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from campusconnect.complaints import complaints_bp
from campusconnect.complaints.forms import ComplaintForm, ComplaintUpdateForm
from campusconnect.complaints.utils import process_new_complaint
from campusconnect.extensions import db
from campusconnect.models import Complaint, ComplaintStatus, ComplaintUpdate, College
from campusconnect.decorators import permission_required


def _save_photo(file_storage):
    if not file_storage or not file_storage.filename:
        return None
    ext = os.path.splitext(secure_filename(file_storage.filename))[1]
    filename = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    file_storage.save(path)
    return filename


@complaints_bp.route("/")
@login_required
def list_complaints():
    colleges = None
    college_filter = None

    if current_user.is_student:
        query = Complaint.query.filter_by(reporter_id=current_user.id)
    else:
        if not current_user.has_permission("manage_complaints"):
            abort(403)

        if current_user.is_master_admin:
            query = Complaint.query
            colleges = College.query.order_by(College.name.asc()).all()
            college_filter = request.args.get("college", type=int)
            if college_filter:
                query = query.filter_by(college_id=college_filter)
        else:
            # A regular admin only ever sees their own college's complaints.
            query = Complaint.query.filter_by(college_id=current_user.college_id)

        status = request.args.get("status")
        priority = request.args.get("priority")
        category = request.args.get("category")
        if status:
            query = query.filter_by(status=status)
        if priority:
            query = query.filter_by(priority=priority)
        if category:
            query = query.filter_by(category=category)

    complaints = query.order_by(Complaint.created_at.desc()).all()
    return render_template("complaints/list.html", complaints=complaints, colleges=colleges, college_filter=college_filter)


@complaints_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_complaint():
    if not current_user.is_student:
        abort(403)  # complaints are filed by students; staff manage them instead

    form = ComplaintForm()
    if form.validate_on_submit():
        photo_filename = _save_photo(form.photo.data)

        complaint = Complaint(
            title=form.title.data.strip(),
            category=form.category.data,
            location=form.location.data.strip(),
            description=form.description.data.strip(),
            is_anonymous=form.is_anonymous.data,
            reporter_id=current_user.id,
            college_id=current_user.college_id,
            photo_filename=photo_filename,
        )
        db.session.add(complaint)
        db.session.flush()  # assign complaint.id before duplicate-detection queries it

        process_new_complaint(complaint)
        db.session.commit()

        if complaint.report_count > 1:
            flash(
                f"Thanks — this matches {complaint.report_count - 1} other report(s) already filed. "
                f"Priority has been raised to {complaint.priority.upper()}.",
                "success",
            )
        else:
            flash("Complaint submitted. You can track its status from your dashboard.", "success")
        return redirect(url_for("complaints.view_complaint", public_id=complaint.public_id))

    return render_template("complaints/new.html", form=form)


@complaints_bp.route("/<public_id>")
@login_required
def view_complaint(public_id):
    complaint = Complaint.query.filter_by(public_id=public_id).first_or_404()

    is_owner = current_user.is_student and complaint.reporter_id == current_user.id
    is_staff_viewer = (
        current_user.is_staff
        and current_user.has_permission("manage_complaints")
        and current_user.can_access_college(complaint.college_id)
    )
    if not (is_owner or is_staff_viewer):
        abort(403)

    update_form = None
    if is_staff_viewer:
        update_form = ComplaintUpdateForm()
        update_form.status.choices = [(s, s.replace("_", " ").title()) for s in ComplaintStatus.ALL]
        update_form.status.data = complaint.status

    # Other complaints merged into the same group, for context.
    related = (
        Complaint.query.filter(
            Complaint.group_id == complaint.group_id, Complaint.id != complaint.id
        ).all()
        if complaint.group_id
        else []
    )

    return render_template(
        "complaints/detail.html",
        complaint=complaint,
        update_form=update_form,
        related=related,
        is_staff_viewer=is_staff_viewer,
    )


@complaints_bp.route("/<public_id>/update", methods=["POST"])
@login_required
@permission_required("manage_complaints")
def update_complaint(public_id):
    complaint = Complaint.query.filter_by(public_id=public_id).first_or_404()

    if not current_user.can_access_college(complaint.college_id):
        abort(403)  # an admin from College A can never touch College B's complaints

    form = ComplaintUpdateForm()
    form.status.choices = [(s, s.replace("_", " ").title()) for s in ComplaintStatus.ALL]

    if form.validate_on_submit():
        old_status = complaint.status
        complaint.status = form.status.data
        if complaint.status == ComplaintStatus.RESOLVED and old_status != ComplaintStatus.RESOLVED:
            from campusconnect.models import now_utc
            complaint.resolved_at = now_utc()
        complaint.assigned_admin_id = current_user.id

        db.session.add(ComplaintUpdate(
            complaint_id=complaint.id,
            author_id=current_user.id,
            note=form.note.data.strip(),
        ))
        db.session.commit()
        flash("Update saved.", "success")
    else:
        flash("Please add a note before saving the update.", "danger")

    return redirect(url_for("complaints.view_complaint", public_id=complaint.public_id))
