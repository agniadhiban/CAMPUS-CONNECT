import hashlib

from flask import render_template, redirect, url_for, flash, abort, request, jsonify
from flask_login import login_required, current_user

from campusconnect.sos import sos_bp
from campusconnect.sos.forms import SOSForm
from campusconnect.extensions import db
from campusconnect.models import SOSAlert, SOSStatus, College, now_utc
from campusconnect.decorators import permission_required


@sos_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_alert():
    if not current_user.is_student:
        abort(403)  # SOS is raised by students; staff respond to it

    form = SOSForm()
    if form.validate_on_submit():
        alert = SOSAlert(
            student_id=current_user.id,
            college_id=current_user.college_id,
            urgency=form.urgency.data,
            location_text=form.location_text.data.strip(),
            message=form.message.data.strip() if form.message.data else None,
            latitude=float(form.latitude.data) if form.latitude.data else None,
            longitude=float(form.longitude.data) if form.longitude.data else None,
        )
        if alert.latitude is not None:
            alert.location_updated_at = now_utc()
        db.session.add(alert)
        db.session.commit()
        flash("SOS alert sent. Campus security/admin has been notified.", "danger")
        # Send the student to a live tracking page - their phone keeps sharing
        # location from here until the alert is resolved.
        return redirect(url_for("sos.track_alert", public_id=alert.public_id))

    return render_template("sos/new.html", form=form)


@sos_bp.route("/<public_id>/track")
@login_required
def track_alert(public_id):
    """Student-facing page shown right after sending an SOS. Keeps sharing
    live location in the background until the alert is resolved."""
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if alert.student_id != current_user.id:
        abort(403)
    return render_template("sos/track.html", alert=alert)


@sos_bp.route("/<public_id>/location-ping", methods=["POST"])
@login_required
def location_ping(public_id):
    """Called repeatedly (every few seconds) from the student's own device
    while their SOS alert is active, to keep their location up to date."""
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if alert.student_id != current_user.id:
        abort(403)
    if alert.status == SOSStatus.RESOLVED:
        return jsonify({"status": alert.status, "tracking": False})

    data = request.get_json(silent=True) or {}
    try:
        lat = float(data.get("latitude"))
        lng = float(data.get("longitude"))
    except (TypeError, ValueError):
        return jsonify({"error": "invalid coordinates"}), 400

    alert.latitude = lat
    alert.longitude = lng
    alert.location_updated_at = now_utc()
    db.session.commit()
    return jsonify({"status": alert.status, "tracking": True})


@sos_bp.route("/<public_id>/status")
@login_required
def alert_status(public_id):
    """Lightweight polling endpoint so the student's tracking page knows
    when staff have acknowledged/resolved the alert, without a full reload."""
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    is_owner = alert.student_id == current_user.id
    is_staff_viewer = current_user.has_permission("manage_sos") and current_user.can_access_college(alert.college_id)
    if not (is_owner or is_staff_viewer):
        abort(403)
    return jsonify({
        "status": alert.status,
        "latitude": alert.latitude,
        "longitude": alert.longitude,
        "location_updated_at": alert.location_updated_at.isoformat() if alert.location_updated_at else None,
    })


def _open_alerts_for_user():
    """Every not-yet-resolved alert this staff member is allowed to see."""
    query = SOSAlert.query.filter(SOSAlert.status != SOSStatus.RESOLVED)
    if not current_user.is_master_admin:
        query = query.filter_by(college_id=current_user.college_id)
    return query.order_by(SOSAlert.created_at.desc()).all()


def _coord(value):
    return "none" if value is None else f"{value:.5f}"


def _signature(alerts):
    """Fingerprint of what the console would show (which alerts, their status,
    and where they are). It changes when the page needs redrawing, but NOT on
    every heartbeat ping from an unmoving phone - so map frames don't flicker."""
    parts = [f"{a.public_id}:{a.status}:{_coord(a.latitude)}:{_coord(a.longitude)}" for a in alerts]
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:16]


@sos_bp.route("/feed")
@login_required
@permission_required("manage_sos")
def feed():
    """Polled every few seconds by staff pages: drives the alarm siren and the
    live refresh of the SOS console. Scoped to the staff member's own college
    (the Master Admin sees every college)."""
    alerts = _open_alerts_for_user()
    payload = {
        "unacknowledged": sum(1 for a in alerts if a.status == SOSStatus.ACTIVE),
        "open": len(alerts),
        "signature": _signature(alerts),
        "alerts": [
            {
                "id": a.public_id,
                "status": a.status,
                "urgency": a.urgency,
                "student": a.student.full_name,
                "location_text": a.location_text,
                "has_gps": a.latitude is not None and a.longitude is not None,
                "updated_at": (a.location_updated_at.isoformat() + "Z") if a.location_updated_at else None,
            }
            for a in alerts
        ],
    }
    response = jsonify(payload)
    response.headers["Cache-Control"] = "no-store"
    return response


@sos_bp.route("/")
@login_required
@permission_required("manage_sos")
def list_alerts():
    colleges = None
    college_filter = None
    if current_user.is_master_admin:
        query = SOSAlert.query
        colleges = College.query.order_by(College.name.asc()).all()
        college_filter = request.args.get("college", type=int)
        if college_filter:
            query = query.filter_by(college_id=college_filter)
    else:
        # An admin only ever sees — and can only ever act on — their own college's alerts.
        query = SOSAlert.query.filter_by(college_id=current_user.college_id)
    alerts = query.order_by(SOSAlert.created_at.desc()).all()
    return render_template(
        "sos/list.html", alerts=alerts, colleges=colleges, college_filter=college_filter,
        signature=_signature(_open_alerts_for_user()),
    )


@sos_bp.route("/<public_id>/acknowledge", methods=["POST"])
@login_required
@permission_required("manage_sos")
def acknowledge(public_id):
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.can_access_college(alert.college_id):
        abort(403)  # an admin from another college can never touch this alert
    alert.status = SOSStatus.ACKNOWLEDGED
    alert.handled_by_id = current_user.id
    alert.acknowledged_at = now_utc()
    db.session.commit()
    flash("Alert acknowledged.", "success")
    return redirect(url_for("sos.list_alerts"))


@sos_bp.route("/<public_id>/resolve", methods=["POST"])
@login_required
@permission_required("manage_sos")
def resolve(public_id):
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.can_access_college(alert.college_id):
        abort(403)
    alert.status = SOSStatus.RESOLVED
    alert.handled_by_id = current_user.id
    alert.resolved_at = now_utc()
    db.session.commit()
    flash("Alert marked resolved.", "success")
    return redirect(url_for("sos.list_alerts"))
