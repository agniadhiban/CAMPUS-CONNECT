from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SelectField, HiddenField, SubmitField
from wtforms.validators import DataRequired, Length, Optional

from campusconnect.models import SOSUrgency


class SOSForm(FlaskForm):
    urgency = SelectField(
        "Urgency",
        choices=[(u, u.title()) for u in SOSUrgency.ALL],
        validators=[DataRequired()],
    )
    location_text = StringField("Where are you? (building / landmark)", validators=[DataRequired(), Length(max=200)])
    message = TextAreaField("What's happening? (optional)", validators=[Optional(), Length(max=1000)])
    latitude = HiddenField()
    longitude = HiddenField()
    submit = SubmitField("Send SOS Alert")
