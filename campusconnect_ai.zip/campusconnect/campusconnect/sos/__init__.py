from flask import Blueprint

sos_bp = Blueprint("sos", __name__, url_prefix="/sos")

from campusconnect.sos import routes  # noqa: E402,F401
