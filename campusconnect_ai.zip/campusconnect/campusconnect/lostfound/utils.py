"""
Lost & Found matching.

When someone posts a "lost" item, we look for an existing unresolved
"found" item that sounds like the same object (and vice versa) - same
college only. If item names and descriptions look alike, we show the match
right on the item's own page, so a student who lost headphones and finds
someone already posted matching headphones as "found" sees it immediately.

Same plain-text-similarity approach as complaint duplicate-detection (see
campusconnect/matching.py) - no external service, explainable, works offline.
"""
from flask import current_app
from sqlalchemy import or_

from campusconnect.matching import text_similarity
from campusconnect.models import LostFoundItem


def find_matches_for(item, limit=5):
    """Return [(candidate_item, score), ...] for the opposite type (lost<->found),
    unresolved, best match first. Empty list if nothing clears the configured
    thresholds.

    College scoping: a post with no college (college_id is None - posted by
    the Master Admin) is visible everywhere, so it can match against ANY
    college's items. A normal college-scoped post can match its own
    college's items, plus any of those global posts."""
    opposite_type = "found" if item.item_type == "lost" else "lost"
    name_threshold = current_app.config["LOSTFOUND_NAME_SIMILARITY_THRESHOLD"]
    match_threshold = current_app.config["LOSTFOUND_MATCH_THRESHOLD"]

    query = LostFoundItem.query.filter(
        LostFoundItem.item_type == opposite_type,
        LostFoundItem.is_resolved.is_(False),
        LostFoundItem.id != item.id,
    )
    if item.college_id is not None:
        query = query.filter(or_(LostFoundItem.college_id == item.college_id, LostFoundItem.college_id.is_(None)))
    # else: item itself is global, so it's eligible to match against every college's posts - no extra filter.

    candidates = query.order_by(LostFoundItem.created_at.desc()).all()

    scored = []
    for candidate in candidates:
        name_score = text_similarity(item.item_name, candidate.item_name)
        if name_score < name_threshold:
            continue
        # Descriptions are often left blank, so let a strong name match carry
        # most of the weight rather than being dragged down by two empty strings.
        desc_score = text_similarity(item.description or "", candidate.description or "")
        combined = name_score * 0.7 + desc_score * 0.3
        if combined < match_threshold:
            continue
        scored.append((candidate, combined))

    scored.sort(key=lambda pair: pair[1], reverse=True)
    return scored[:limit]
