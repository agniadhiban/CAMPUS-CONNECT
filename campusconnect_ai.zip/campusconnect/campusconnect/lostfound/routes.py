import os
import uuid

from flask import render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from sqlalchemy import or_
from werkzeug.utils import secure_filename

from campusconnect.lostfound import lostfound_bp
from campusconnect.lostfound.forms import LostFoundForm
from campusconnect.lostfound.utils import find_matches_for
from campusconnect.extensions import db
from campusconnect.models import LostFoundItem, College, now_utc
from campusconnect.decorators import permission_required


def _save_photo(file_storage):
    if not file_storage or not file_storage.filename:
        return None
    ext = os.path.splitext(secure_filename(file_storage.filename))[1]
    filename = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    file_storage.save(path)
    return filename


def _can_view_item(item):
    """A post is visible if it's the viewer's own college, OR it has no
    college at all (college_id is None = posted by the Master Admin, who
    belongs to none - treated as visible to every college, the same way a
    Master Admin announcement with no college is a global broadcast)."""
    if item.college_id is None:
        return True
    return current_user.can_access_college(item.college_id)


@lostfound_bp.route("/")
@login_required
def list_items():
    item_type = request.args.get("type")  # lost | found | None
    query = LostFoundItem.query.filter_by(is_resolved=False)

    colleges = None
    college_filter = None
    if current_user.is_master_admin:
        colleges = College.query.order_by(College.name.asc()).all()
        college_filter = request.args.get("college", type=int)
        if college_filter:
            # Still include global (no-college) posts alongside the filtered college's own.
            query = query.filter(or_(LostFoundItem.college_id == college_filter, LostFoundItem.college_id.is_(None)))
    else:
        # Students and regular admins see their own college's board, plus any
        # global posts (e.g. something posted by the Master Admin).
        query = query.filter(or_(LostFoundItem.college_id == current_user.college_id, LostFoundItem.college_id.is_(None)))

    if item_type in ("lost", "found"):
        query = query.filter_by(item_type=item_type)
    items = query.order_by(LostFoundItem.created_at.desc()).all()
    return render_template("lostfound/list.html", items=items, active_filter=item_type, colleges=colleges, college_filter=college_filter)


@lostfound_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_item():
    form = LostFoundForm()
    if form.validate_on_submit():
        photo_filename = _save_photo(form.photo.data)
        item = LostFoundItem(
            item_type=form.item_type.data,
            item_name=form.item_name.data.strip(),
            description=form.description.data.strip() if form.description.data else None,
            location=form.location.data.strip() if form.location.data else None,
            contact_info=form.contact_info.data.strip() if form.contact_info.data else None,
            photo_filename=photo_filename,
            reported_by_id=current_user.id,
            college_id=current_user.college_id,  # None for the Master Admin -> visible to every college, by design
        )
        db.session.add(item)
        db.session.commit()

        matches = find_matches_for(item)
        if matches:
            other_type = "found" if item.item_type == "lost" else "lost"
            flash(
                f"Posted! We also found {len(matches)} similar {other_type} item(s) that might be a match — see below.",
                "success",
            )
        elif current_user.is_master_admin:
            flash("Posted to Lost & Found — visible to every college (posted by the Master Admin).", "success")
        else:
            flash("Posted to Lost & Found.", "success")
        return redirect(url_for("lostfound.view_item", public_id=item.public_id))
    return render_template("lostfound/new.html", form=form)


@lostfound_bp.route("/<public_id>")
@login_required
def view_item(public_id):
    item = LostFoundItem.query.filter_by(public_id=public_id).first_or_404()
    if not _can_view_item(item):
        abort(403)  # never let one college browse into another's lost & found

    # Recomputed on every visit (not just at posting time) so a match still
    # shows up even if the OTHER post came later - e.g. Alice posts "lost
    # headphones" today, Bob posts "found headphones" tomorrow; the next time
    # Alice opens her own post, she'll see Bob's.
    matches = find_matches_for(item) if not item.is_resolved else []
    return render_template("lostfound/detail.html", item=item, matches=matches)


@lostfound_bp.route("/<public_id>/resolve", methods=["POST"])
@login_required
def resolve_item(public_id):
    item = LostFoundItem.query.filter_by(public_id=public_id).first_or_404()
    if not _can_view_item(item):
        abort(403)

    is_owner = item.reported_by_id == current_user.id
    is_staff = current_user.is_staff and current_user.has_permission("manage_lostfound")
    if not (is_owner or is_staff):
        abort(403)

    item.is_resolved = True
    item.resolved_at = now_utc()
    db.session.commit()
    flash("Marked as resolved / returned.", "success")
    return redirect(url_for("lostfound.list_items"))
