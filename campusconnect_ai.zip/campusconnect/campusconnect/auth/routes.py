from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user

from campusconnect.auth import auth_bp
from campusconnect.auth.forms import LoginForm, StudentRegisterForm, ChangePasswordForm
from campusconnect.extensions import db
from campusconnect.models import User, Role, College


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        identifier = form.identifier.data.strip().lower()
        user = User.query.filter(
            (User.username == identifier) | (User.email == identifier)
        ).first()

        if user is None or not user.check_password(form.password.data):
            flash("Incorrect username/email or password.", "danger")
            return render_template("auth/login.html", form=form)

        if not user.is_active_account:
            flash("This account has been disabled. Contact the campus admin office.", "danger")
            return render_template("auth/login.html", form=form)

        login_user(user, remember=form.remember.data)
        flash(f"Welcome back, {user.full_name.split(' ')[0]}!", "success")
        next_page = request.args.get("next")
        return redirect(next_page or url_for("main.dashboard"))

    return render_template("auth/login.html", form=form)


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    """Self-registration is for students only. Admin accounts are created by
    the Master Admin from inside the admin panel — never through this form.
    Every student must pick their college; they'll only ever see that
    college's complaints, lost & found, announcements, and SOS console."""
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))

    active_colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all()
    if not active_colleges:
        flash("No colleges are set up yet. Ask your campus admin to add your college first.", "warning")
        return redirect(url_for("auth.login"))

    form = StudentRegisterForm()
    form.college_id.choices = [(c.id, c.name) for c in active_colleges]

    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        username = form.username.data.strip().lower()

        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
            return render_template("auth/register.html", form=form)
        if User.query.filter_by(username=username).first():
            flash("That username is taken. Please choose another.", "danger")
            return render_template("auth/register.html", form=form)

        user = User(
            full_name=form.full_name.data.strip(),
            email=email,
            username=username,
            role=Role.STUDENT,
            college_id=form.college_id.data,
            student_id=form.student_id.data.strip() if form.student_id.data else None,
            department=form.department.data.strip() if form.department.data else None,
            phone=form.phone.data.strip() if form.phone.data else None,
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()

        flash("Account created! You can log in now.", "success")
        return redirect(url_for("auth.login"))

    return render_template("auth/register.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You've been logged out.", "info")
    return redirect(url_for("auth.login"))


@auth_bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current_password.data):
            flash("Current password is incorrect.", "danger")
            return render_template("auth/change_password.html", form=form)
        current_user.set_password(form.new_password.data)
        db.session.commit()
        flash("Password updated.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("auth/change_password.html", form=form)
