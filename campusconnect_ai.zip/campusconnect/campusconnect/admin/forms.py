from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SelectMultipleField, SelectField, SubmitField, widgets
from wtforms.validators import DataRequired, Email, Length, Optional

from campusconnect.models import ADMIN_PERMISSIONS


class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(prefix_label=False)
    option_widget = widgets.CheckboxInput()


class CollegeForm(FlaskForm):
    name = StringField("College name", validators=[DataRequired(), Length(max=150)])
    code = StringField("Short code (optional)", validators=[Optional(), Length(max=20)])
    address = StringField("Address (optional)", validators=[Optional(), Length(max=255)])
    submit = SubmitField("Add college")


class CreateAdminForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(max=120)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=150)])
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=80)])
    department = StringField("Department / office", validators=[Length(max=120)])
    college_id = SelectField("College", coerce=int, validators=[DataRequired()])
    password = PasswordField("Temporary password", validators=[DataRequired(), Length(min=6)])
    permissions = MultiCheckboxField(
        "Permissions", choices=ADMIN_PERMISSIONS, validators=[Optional()]
    )
    submit = SubmitField("Create admin account")


class EditPermissionsForm(FlaskForm):
    permissions = MultiCheckboxField(
        "Permissions", choices=ADMIN_PERMISSIONS, validators=[Optional()]
    )
    submit = SubmitField("Save permissions")
