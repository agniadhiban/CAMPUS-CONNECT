from flask import render_template, redirect, url_for, flash, abort, request
from flask_login import login_required, current_user

from campusconnect.admin import admin_bp
from campusconnect.admin.forms import CreateAdminForm, EditPermissionsForm, CollegeForm
from campusconnect.extensions import db
from campusconnect.models import User, Role, College
from campusconnect.decorators import roles_required


# ---------------------------------------------------------------------------
# Colleges (Master Admin only) — this is what lets one deployment serve many
# institutions, each with its own admins and students who only see their own.
# ---------------------------------------------------------------------------
@admin_bp.route("/colleges")
@login_required
@roles_required(Role.MASTER_ADMIN)
def list_colleges():
    colleges = College.query.order_by(College.name.asc()).all()
    # Precompute counts so the template doesn't run N+1 queries per row.
    counts = {}
    for c in colleges:
        counts[c.id] = {
            "students": User.query.filter_by(college_id=c.id, role=Role.STUDENT).count(),
            "admins": User.query.filter_by(college_id=c.id, role=Role.ADMIN).count(),
        }
    return render_template("admin/colleges_list.html", colleges=colleges, counts=counts)


@admin_bp.route("/colleges/new", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def new_college():
    form = CollegeForm()
    if form.validate_on_submit():
        name = form.name.data.strip()
        code = form.code.data.strip().upper() if form.code.data else None

        if College.query.filter_by(name=name).first():
            flash("A college with that name already exists.", "danger")
            return render_template("admin/new_college.html", form=form)
        if code and College.query.filter_by(code=code).first():
            flash("That short code is already used by another college.", "danger")
            return render_template("admin/new_college.html", form=form)

        college = College(
            name=name,
            code=code,
            address=form.address.data.strip() if form.address.data else None,
            created_by_id=current_user.id,
        )
        db.session.add(college)
        db.session.commit()
        flash(f"{college.name} added. You can now create admins and students under it.", "success")
        return redirect(url_for("admin.list_colleges"))

    return render_template("admin/new_college.html", form=form)


@admin_bp.route("/colleges/<int:college_id>/toggle-active", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_college_active(college_id):
    college = College.query.get_or_404(college_id)
    college.is_active = not college.is_active
    db.session.commit()
    state = "enabled" if college.is_active else "disabled"
    flash(f"{college.name} has been {state}. {'New signups can use it again.' if college.is_active else 'It will no longer appear for new signups (existing accounts are unaffected).'}", "success")
    return redirect(url_for("admin.list_colleges"))


# ---------------------------------------------------------------------------
# Admin (staff) accounts — Master Admin only, each admin tied to one college
# ---------------------------------------------------------------------------
@admin_bp.route("/staff")
@login_required
@roles_required(Role.MASTER_ADMIN)
def list_staff():
    college_filter = request.args.get("college", type=int)
    query = User.query.filter_by(role=Role.ADMIN)
    if college_filter:
        query = query.filter_by(college_id=college_filter)
    admins = query.order_by(User.created_at.desc()).all()
    colleges = College.query.order_by(College.name.asc()).all()
    return render_template("admin/staff_list.html", admins=admins, colleges=colleges, college_filter=college_filter)


@admin_bp.route("/staff/new", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def new_admin():
    active_colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all()
    if not active_colleges:
        flash("Add a college first before creating an admin account.", "warning")
        return redirect(url_for("admin.new_college"))

    form = CreateAdminForm()
    form.college_id.choices = [(c.id, c.name) for c in active_colleges]

    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        username = form.username.data.strip().lower()

        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
            return render_template("admin/new_staff.html", form=form)
        if User.query.filter_by(username=username).first():
            flash("That username is taken.", "danger")
            return render_template("admin/new_staff.html", form=form)

        admin = User(
            full_name=form.full_name.data.strip(),
            email=email,
            username=username,
            role=Role.ADMIN,
            department=form.department.data.strip() if form.department.data else None,
            college_id=form.college_id.data,
            permissions=",".join(form.permissions.data),
            created_by_id=current_user.id,
        )
        admin.set_password(form.password.data)
        db.session.add(admin)
        db.session.commit()
        flash(f"Admin account created for {admin.full_name}. Share the temporary password securely.", "success")
        return redirect(url_for("admin.list_staff"))

    return render_template("admin/new_staff.html", form=form)


@admin_bp.route("/staff/<int:user_id>/permissions", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def edit_permissions(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    form = EditPermissionsForm()

    if form.validate_on_submit():
        admin.permissions = ",".join(form.permissions.data)
        db.session.commit()
        flash(f"Permissions updated for {admin.full_name}.", "success")
        return redirect(url_for("admin.list_staff"))

    form.permissions.data = (admin.permissions or "").split(",")
    return render_template("admin/edit_permissions.html", form=form, admin=admin)


@admin_bp.route("/staff/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_staff_active(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    admin.is_active_account = not admin.is_active_account
    db.session.commit()
    state = "enabled" if admin.is_active_account else "disabled"
    flash(f"{admin.full_name}'s account has been {state}.", "success")
    return redirect(url_for("admin.list_staff"))


@admin_bp.route("/staff/<int:user_id>/remove", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def remove_admin(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    name = admin.full_name
    db.session.delete(admin)
    db.session.commit()
    flash(f"Removed admin account for {name}.", "success")
    return redirect(url_for("admin.list_staff"))


# ---------------------------------------------------------------------------
# Students — regular admins see only their own college; Master Admin sees all
# ---------------------------------------------------------------------------
@admin_bp.route("/students")
@login_required
@roles_required(Role.MASTER_ADMIN, Role.ADMIN)
def list_students():
    if not (current_user.is_master_admin or current_user.has_permission("manage_complaints")):
        abort(403)

    query = User.query.filter_by(role=Role.STUDENT)
    colleges = None
    college_filter = None

    if current_user.is_master_admin:
        colleges = College.query.order_by(College.name.asc()).all()
        college_filter = request.args.get("college", type=int)
        if college_filter:
            query = query.filter_by(college_id=college_filter)
    else:
        # Regular admins never see another college's students, no matter what.
        query = query.filter_by(college_id=current_user.college_id)

    students = query.order_by(User.created_at.desc()).all()
    return render_template("admin/students_list.html", students=students, colleges=colleges, college_filter=college_filter)


@admin_bp.route("/students/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_student_active(user_id):
    student = User.query.filter_by(id=user_id, role=Role.STUDENT).first_or_404()
    student.is_active_account = not student.is_active_account
    db.session.commit()
    state = "enabled" if student.is_active_account else "disabled"
    flash(f"{student.full_name}'s account has been {state}.", "success")
    return redirect(url_for("admin.list_students"))
