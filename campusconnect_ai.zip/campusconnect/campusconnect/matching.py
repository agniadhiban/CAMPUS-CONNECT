"""
Plain-text similarity helper shared by two features that both need to
recognize "this is probably the same real-world thing, worded differently":

  - campusconnect/complaints/utils.py — merges duplicate complaints and
    escalates priority.
  - campusconnect/lostfound/utils.py — matches a "lost" post against a
    "found" post (or vice versa).

Kept as plain string comparison (no external ML service) on purpose: it
works offline, costs nothing, and is easy to explain in a demo/viva.
"""
import re
import difflib


def normalize_text(text):
    if not text:
        return ""
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text


def text_similarity(a, b):
    """0.0-1.0 similarity between two strings, order-independent, case/punctuation-insensitive."""
    a, b = normalize_text(a), normalize_text(b)
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()
