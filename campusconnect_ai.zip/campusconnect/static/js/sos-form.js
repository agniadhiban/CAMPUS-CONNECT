/*
 * SOS form: grab a GPS position up front (so the alert has a location from
 * the first second), explain clearly if that isn't possible, and remember
 * whether the student wants the siren on the next page.
 */
(function () {
  "use strict";

  var form = document.getElementById("sos-form");
  if (!form) return;

  var status = document.getElementById("geo-status");
  var box = document.getElementById("geo-box");
  var retry = document.getElementById("geo-retry");
  var lat = document.getElementById("latitude");
  var lng = document.getElementById("longitude");

  function say(text, tone) {
    status.textContent = text;
    var palette = {
      ok: "border-emerald-300 bg-emerald-50 text-emerald-800",
      warn: "border-amber-300 bg-amber-50 text-amber-800",
      bad: "border-red-300 bg-red-50 text-red-800",
      info: "border-slate-200 bg-slate-50 text-slate-600"
    };
    box.className = "text-sm rounded-lg border p-3 mb-3 " + palette[tone || "info"];
  }

  function locate() {
    retry.classList.add("hidden");

    if (window.isSecureContext === false) {
      say("Live GPS can't work on this page because it is plain http. Phones only allow GPS on https pages. You can still send the alert \u2014 type where you are above.", "bad");
      return;
    }
    if (!navigator.geolocation) {
      say("This device can't share GPS. Please type where you are above.", "warn");
      return;
    }

    say("Getting your location\u2026 tap Allow if your phone asks.", "info");
    navigator.geolocation.getCurrentPosition(function (pos) {
      lat.value = pos.coords.latitude;
      lng.value = pos.coords.longitude;
      var acc = pos.coords.accuracy ? " (accuracy about " + Math.round(pos.coords.accuracy) + " m)" : "";
      say("\uD83D\uDCCD GPS location attached" + acc + ". It keeps updating live after you send.", "ok");
    }, function (err) {
      retry.classList.remove("hidden");
      if (err && err.code === 1) {
        say("Location is blocked. Allow Location for this site in your browser settings, then try again. You can still send the alert \u2014 type where you are above.", "bad");
      } else if (err && err.code === 2) {
        say("No GPS signal. Turn Location ON in your phone settings and try again. You can still send the alert.", "warn");
      } else {
        say("Still looking for GPS\u2026 you can send now; it will keep searching after you send.", "warn");
      }
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 });
  }

  retry.addEventListener("click", locate);

  form.addEventListener("submit", function () {
    var opt = document.getElementById("siren-opt");
    try { sessionStorage.setItem("sos_siren_pending", opt && opt.checked ? "1" : "0"); } catch (e) { /* ignore */ }
  });

  // Test-the-alarm button. This is a direct tap on THIS page, which is the
  // one kind of user action browsers always honour for sound - so this is
  // also how a student can be sure their phone isn't on silent BEFORE they
  // actually need the siren, rather than finding out during an emergency.
  var previewBtn = document.getElementById("siren-preview");
  var previewNote = document.getElementById("siren-preview-note");
  if (previewBtn && window.CampusSiren) {
    previewBtn.addEventListener("click", function () {
      previewBtn.disabled = true;
      previewBtn.textContent = "\uD83D\uDD0A Playing\u2026";
      window.CampusSiren.start().then(function (ok) {
        previewNote.classList.remove("hidden");
        if (ok) {
          previewNote.textContent = "Good \u2014 you heard that. The alert will sound the same way.";
          previewNote.className = "text-xs text-emerald-700 mt-1";
        } else {
          previewNote.textContent = "No sound played. Check your phone isn't on silent/mute, then try again.";
          previewNote.className = "text-xs text-red-700 font-semibold mt-1";
        }
        setTimeout(function () {
          window.CampusSiren.stop();
          previewBtn.disabled = false;
          previewBtn.textContent = "\uD83D\uDD0A Test my alarm sound now (recommended)";
        }, 1500);
      });
    });
  }

  locate();
})();
