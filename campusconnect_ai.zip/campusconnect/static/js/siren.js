/*
 * CampusSiren — plays a looping siren and vibrates the device (where the
 * browser supports it). Used by the student SOS page and the admin alarm.
 *
 * Browser rules this has to live with:
 *  - Browsers only allow sound after the person has tapped/clicked the page.
 *    start() therefore RESOLVES TO false when the browser blocks it, so the
 *    calling page can show a "tap to enable sound" button.
 *  - Vibration works on Android browsers. iPhones do not support it at all.
 */
(function () {
  "use strict";

  var script = document.currentScript;
  var src = script && script.src
    ? script.src.replace(/js\/siren\.js.*$/, "audio/siren.wav")
    : "/static/audio/siren.wav";

  var audio = null;
  var vibTimer = null;
  var VIBE_PATTERN = [600, 250, 600, 250, 600, 250]; // buzz-buzz-buzz
  var VIBE_REPEAT_MS = 2600;

  function getAudio() {
    if (!audio) {
      audio = new Audio(src);
      audio.loop = true;
      audio.preload = "auto";
      audio.volume = 1.0;
    }
    return audio;
  }

  function vibrate(pattern) {
    try {
      if (navigator.vibrate) return navigator.vibrate(pattern);
    } catch (e) { /* ignore */ }
    return false;
  }

  function startVibration() {
    if (!navigator.vibrate) return;
    stopVibrationTimer();
    vibrate(VIBE_PATTERN);
    vibTimer = setInterval(function () { vibrate(VIBE_PATTERN); }, VIBE_REPEAT_MS);
  }

  function stopVibrationTimer() {
    if (vibTimer) { clearInterval(vibTimer); vibTimer = null; }
  }

  function stopVibration() {
    stopVibrationTimer();
    vibrate(0);
  }

  function isPlaying() {
    return !!audio && !audio.paused;
  }

  // Resolves true if the siren is sounding, false if the browser blocked it.
  function start() {
    if (isPlaying()) return Promise.resolve(true);
    var a = getAudio();
    startVibration();
    var p;
    try { p = a.play(); } catch (e) { return Promise.resolve(false); }
    if (p && typeof p.then === "function") {
      return p.then(function () { return true; }, function () { return false; });
    }
    return Promise.resolve(true);
  }

  function stop() {
    if (audio) {
      try { audio.pause(); audio.currentTime = 0; } catch (e) { /* ignore */ }
    }
    stopVibration();
  }

  window.CampusSiren = {
    start: start,
    stop: stop,
    isPlaying: isPlaying,
    canVibrate: !!navigator.vibrate
  };
})();
