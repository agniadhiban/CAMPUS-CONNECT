/*
 * Student SOS tracking page.
 *
 *  - Streams the phone's GPS position to the server while the alert is open.
 *  - Reports the TRUTH on screen: what the GPS is doing and whether the
 *    server actually received the last position (the old page claimed
 *    "sharing" even when nothing was getting through).
 *  - Sends a heartbeat every few seconds so a phone that isn't moving still
 *    shows as live to the admin.
 *  - Keeps the screen awake (a sleeping phone stops sharing location).
 *  - Sounds the siren + vibrates, with a big Silence button.
 */
(function () {
  "use strict";

  var root = document.getElementById("track-root");
  if (!root) return;

  var alertId = root.dataset.alertId;
  var csrf = document.querySelector('meta[name="csrf-token"]').content;
  var siren = window.CampusSiren;
  var MIN_GAP_MS = 3000;        // never send positions more often than this
  var HEARTBEAT_MS = 8000;      // refresh position at least this often
  var STATUS_POLL_MS = 5000;

  function $(id) { return document.getElementById(id); }

  // ---- state --------------------------------------------------------------
  var tracking = true;
  var watchId = null;
  var lastPos = null;           // last GPS fix from the phone
  var lastSentAt = 0;           // last time the SERVER confirmed a position
  var lastAttemptAt = 0;
  var inFlight = false;
  var pings = 0;
  var gpsError = null;          // "denied" | "insecure" | "unavailable" | "timeout" | "unsupported"
  var serverError = null;
  var wakeLock = null;
  var sirenWanted = false;
  var sirenKey = "sos_siren_on_" + alertId;

  // ---- GPS status text ----------------------------------------------------
  function renderGps() {
    var title = $("gps-title"), detail = $("gps-detail"), box = $("gps-box");
    var retry = $("gps-retry");
    var tone = "slate", t = "", d = "";

    if (!tracking) {
      tone = "slate"; t = "Location sharing stopped"; d = "";
    } else if (gpsError === "insecure") {
      tone = "red"; t = "GPS is blocked on this page";
      d = "Phones only allow GPS on secure (https) pages, and this page is plain http. Your alert was still sent, and admins can see the location you typed. To share live GPS, open the https:// version of this site.";
      $("https-warning").classList.remove("hidden");
    } else if (gpsError === "denied") {
      tone = "red"; t = "Location permission is blocked";
      d = "Tap the lock/info icon next to the web address, set Location to Allow, then press the button below.";
    } else if (gpsError === "unsupported") {
      tone = "red"; t = "This device can't share GPS"; d = "Admins can still see the location you typed.";
    } else if (gpsError === "unavailable") {
      tone = "amber"; t = "No GPS signal";
      d = "Turn Location ON in your phone settings and move near a window or outdoors. Still trying\u2026";
    } else if (serverError && lastPos) {
      tone = "amber"; t = "GPS found, but can't reach the server";
      d = "Check your internet connection. Retrying automatically\u2026";
    } else if (lastSentAt) {
      var secs = Math.max(0, Math.round((Date.now() - lastSentAt) / 1000));
      var acc = lastPos && lastPos.coords.accuracy ? " \u00B7 accuracy about " + Math.round(lastPos.coords.accuracy) + " m" : "";
      tone = secs > 30 ? "amber" : "green";
      t = secs > 30 ? "Live location \u2014 last sent " + secs + "s ago" : "Sharing live location";
      d = "Last sent " + (secs < 3 ? "just now" : secs + "s ago") + acc + " \u00B7 " + pings + " updates sent";
    } else if (gpsError === "timeout") {
      tone = "amber"; t = "Searching for GPS signal\u2026"; d = "This can take up to a minute. Keep this page open.";
    } else {
      tone = "slate"; t = "Waiting for location permission\u2026";
      d = "If your phone asks to allow location, tap Allow.";
    }

    title.textContent = t;
    detail.textContent = d;
    var palette = {
      green: "bg-emerald-50 border-emerald-300 text-emerald-800",
      amber: "bg-amber-50 border-amber-300 text-amber-800",
      red: "bg-red-50 border-red-300 text-red-800",
      slate: "bg-slate-50 border-slate-200 text-slate-700"
    };
    box.className = "border rounded-xl p-4 text-left " + palette[tone];
    retry.classList.toggle("hidden", !(tracking && (gpsError === "denied" || gpsError === "unavailable" || gpsError === "timeout" || (!lastPos && !gpsError))));
  }

  // ---- sending positions ---------------------------------------------------
  function send(pos) {
    if (!tracking || inFlight) return;
    var now = Date.now();
    if (now - lastAttemptAt < MIN_GAP_MS) return;
    lastAttemptAt = now;
    inFlight = true;

    fetch("/sos/" + alertId + "/location-ping", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRFToken": csrf },
      body: JSON.stringify({ latitude: pos.coords.latitude, longitude: pos.coords.longitude })
    })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        serverError = null;
        lastSentAt = Date.now();
        pings += 1;
        if (data.tracking === false || data.status === "resolved") markResolved();
      })
      .catch(function (e) { serverError = String(e && e.message || e); })
      .then(function () { inFlight = false; renderGps(); });
  }

  function onPosition(pos) {
    lastPos = pos;
    gpsError = null;
    send(pos);
    renderGps();
  }

  function onGpsError(err) {
    if (err && err.code === 1) {
      gpsError = window.isSecureContext === false ? "insecure" : "denied";
    } else if (err && err.code === 2) {
      gpsError = "unavailable";
    } else {
      gpsError = "timeout"; // keep watching; a fix usually arrives shortly
    }
    renderGps();
  }

  function startTracking() {
    if (!tracking) return;
    if (!navigator.geolocation) { gpsError = "unsupported"; renderGps(); return; }
    if (window.isSecureContext === false) {
      // Browsers refuse GPS here. Say so clearly, but still try (some allow it).
      $("https-warning").classList.remove("hidden");
    }
    if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
    gpsError = null;
    renderGps();
    watchId = navigator.geolocation.watchPosition(onPosition, onGpsError, {
      enableHighAccuracy: true, maximumAge: 0, timeout: 20000
    });
  }

  // A phone that isn't moving may never trigger watchPosition again, so ask
  // for a fresh fix every few seconds to keep the admin's map "live".
  function heartbeat() {
    if (!tracking) return;
    if (navigator.geolocation && Date.now() - lastSentAt >= HEARTBEAT_MS) {
      navigator.geolocation.getCurrentPosition(onPosition, function () {}, {
        enableHighAccuracy: true, maximumAge: HEARTBEAT_MS, timeout: 10000
      });
    }
  }

  // ---- keep the screen awake ----------------------------------------------
  function requestWake() {
    if (!tracking || !("wakeLock" in navigator)) return;
    navigator.wakeLock.request("screen").then(function (lock) {
      wakeLock = lock;
      lock.addEventListener("release", function () { wakeLock = null; });
    }).catch(function () { /* not supported / denied: fine */ });
  }

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && tracking) {
      requestWake();
      heartbeat();
    }
  });

  // ---- siren ----------------------------------------------------------------
  function setSirenUi(state) {
    var btn = $("siren-btn"), note = $("siren-note"), tap = $("siren-tap");
    var blocked = state === "blocked";
    if (state === "on") {
      btn.textContent = "\uD83D\uDD07 Silence siren";
      btn.className = "w-full bg-slate-800 hover:bg-black text-white font-bold py-3 rounded-xl";
      note.textContent = siren.canVibrate ? "Siren is sounding and your phone is vibrating." : "Siren is sounding.";
    } else if (state === "blocked") {
      btn.textContent = "\uD83D\uDD0A Sound siren";
      btn.className = "w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl";
      note.textContent = "Your browser needs one tap before it will play sound.";
    } else {
      btn.textContent = "\uD83D\uDD0A Sound siren";
      btn.className = "w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-xl";
      note.textContent = "Siren is off. Tap to sound a loud alarm and vibrate your phone.";
    }
    // Applied LAST, after the className resets above, so it actually sticks:
    // only one call-to-action (the big pulsing banner, or this normal button) shows at a time.
    tap.classList.toggle("hidden", !blocked);
    btn.classList.toggle("hidden", blocked);
  }

  function sirenOn() {
    sirenWanted = true;
    try { sessionStorage.setItem(sirenKey, "1"); } catch (e) { /* ignore */ }
    return siren.start().then(function (ok) { setSirenUi(ok ? "on" : "blocked"); });
  }

  function sirenOff() {
    sirenWanted = false;
    try { sessionStorage.removeItem(sirenKey); } catch (e) { /* ignore */ }
    siren.stop();
    setSirenUi("off");
  }

  $("siren-btn").addEventListener("click", function () {
    if (siren.isPlaying()) sirenOff(); else sirenOn();
  });
  $("siren-tap").addEventListener("click", function () { sirenOn(); });

  // If the browser blocked the sound, the very next tap anywhere starts it.
  ["pointerdown", "keydown"].forEach(function (evt) {
    document.addEventListener(evt, function () {
      if (tracking && sirenWanted && !siren.isPlaying()) sirenOn();
    }, { passive: true });
  });

  $("gps-retry").addEventListener("click", function () {
    gpsError = null;
    startTracking();
  });

  // ---- status / resolution --------------------------------------------------
  function setStatus(status) {
    $("status-value").textContent = status.replace("_", " ");
    if (status === "acknowledged") {
      $("status-title").textContent = "Help has seen your alert";
      $("status-sub").textContent = "An admin has acknowledged your SOS and is responding. Stay safe and keep this page open.";
    }
  }

  function markResolved() {
    tracking = false;
    if (watchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    watchId = null;
    sirenOff();
    if (wakeLock) { try { wakeLock.release(); } catch (e) { /* ignore */ } }
    $("status-icon").textContent = "\u2705";
    $("status-title").textContent = "You're marked safe";
    $("status-title").className = "text-2xl font-extrabold text-emerald-700 mb-1";
    $("status-sub").textContent = "This alert has been resolved. Location sharing and the siren have stopped.";
    $("status-value").textContent = "resolved";
    $("siren-box").classList.add("hidden");
    renderGps();
  }

  function pollStatus() {
    if (!tracking) return;
    fetch("/sos/" + alertId + "/status", { credentials: "same-origin" })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.status === "resolved") { markResolved(); return; }
        setStatus(data.status);
        setTimeout(pollStatus, STATUS_POLL_MS);
      })
      .catch(function () { setTimeout(pollStatus, 8000); });
  }

  // ---- go -------------------------------------------------------------------
  if (root.dataset.status === "resolved") {
    markResolved();
    return;
  }

  setSirenUi("off");
  var pending = null;
  try { pending = sessionStorage.getItem("sos_siren_pending"); sessionStorage.removeItem("sos_siren_pending"); } catch (e) { /* ignore */ }
  var wasOn = null;
  try { wasOn = sessionStorage.getItem(sirenKey); } catch (e) { /* ignore */ }
  if (pending === "1" || wasOn === "1") sirenOn();

  startTracking();
  requestWake();
  setInterval(heartbeat, HEARTBEAT_MS);
  setInterval(renderGps, 1000);
  pollStatus();
})();
