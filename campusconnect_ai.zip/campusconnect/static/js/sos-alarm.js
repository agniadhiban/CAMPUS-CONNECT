/*
 * Staff SOS alarm. Loaded on every page for admins who can manage SOS alerts.
 *
 *  - Polls /sos/feed every few seconds.
 *  - While any alert is still "active" (nobody has acknowledged it), shows a
 *    red banner and sounds the siren + vibrates. Acknowledging or resolving
 *    the alert stops it. "Silence" mutes only the alerts you already know
 *    about; a NEW alert sounds the siren again.
 *  - On the SOS console page (#alerts-root) it redraws the alert cards in
 *    place when something changes, so the page never reloads (a reload would
 *    cut the audio) and live locations stay fresh.
 */
(function () {
  "use strict";

  var siren = window.CampusSiren;
  var banner = document.getElementById("sos-alarm-banner");
  if (!siren || !banner) return;

  var POLL_MS = 5000;
  var textEl = document.getElementById("sos-alarm-text");
  var toggleBtn = document.getElementById("sos-alarm-toggle");
  var root = document.getElementById("alerts-root");
  var testBtn = document.getElementById("alarm-test");
  var soundSwitch = document.getElementById("alarm-sound-switch");
  var baseTitle = document.title;

  var lastFeed = null;
  var refreshing = false;
  var testTimer = null;
  var audioBlocked = false;
  var mutedIds = readJson(sessionStorage, "sos_muted", []);
  var soundOn = readValue(localStorage, "sos_sound") !== "off";

  function readValue(store, key) { try { return store.getItem(key); } catch (e) { return null; } }
  function writeValue(store, key, v) { try { store.setItem(key, v); } catch (e) { /* ignore */ } }
  function readJson(store, key, fallback) {
    try { return JSON.parse(store.getItem(key) || "null") || fallback; } catch (e) { return fallback; }
  }

  function waitingIds(feed) {
    return feed.alerts.filter(function (a) { return a.status === "active"; }).map(function (a) { return a.id; });
  }

  function shouldSound(feed) {
    if (!soundOn) return false;
    return waitingIds(feed).some(function (id) { return mutedIds.indexOf(id) === -1; });
  }

  function renderBanner() {
    if (!lastFeed) return;
    var ids = waitingIds(lastFeed);
    if (!ids.length) {
      banner.classList.add("hidden");
      document.title = baseTitle;
      return;
    }
    banner.classList.remove("hidden");
    document.title = "\uD83D\uDEA8 (" + ids.length + ") " + baseTitle;

    var label = ids.length + " SOS alert" + (ids.length > 1 ? "s" : "") + " waiting for a response";
    if (siren.isPlaying()) {
      textEl.textContent = "\uD83D\uDEA8 " + label;
      toggleBtn.textContent = "\uD83D\uDD07 Silence";
    } else if (shouldSound(lastFeed)) {
      textEl.textContent = "\uD83D\uDEA8 " + label + " \u2014 tap to turn the alarm sound on";
      toggleBtn.textContent = "\uD83D\uDD0A Enable sound";
    } else {
      textEl.textContent = "\uD83D\uDEA8 " + label + (soundOn ? " (siren silenced)" : " (alarm sound is off)");
      toggleBtn.textContent = "\uD83D\uDD0A Sound siren";
    }
  }

  function tryStart() {
    return siren.start().then(function (ok) {
      audioBlocked = !ok;
      renderBanner();
      return ok;
    });
  }

  function applyFeed(feed) {
    lastFeed = feed;
    var ids = waitingIds(feed);
    // forget silenced ids for alerts that no longer need a response
    mutedIds = mutedIds.filter(function (id) { return ids.indexOf(id) !== -1; });
    writeValue(sessionStorage, "sos_muted", JSON.stringify(mutedIds));

    if (shouldSound(feed)) {
      if (!siren.isPlaying()) tryStart();
    } else if (!testTimer) {
      if (siren.isPlaying()) siren.stop();
      audioBlocked = false;
    }
    renderBanner();
    updateAgoTimestamps(feed);
    maybeRedrawConsole(feed);
  }

  // ---- banner / buttons ---------------------------------------------------
  toggleBtn.addEventListener("click", function () {
    if (!lastFeed) return;
    if (siren.isPlaying()) {
      // silence just the alerts we know about right now
      mutedIds = waitingIds(lastFeed);
      writeValue(sessionStorage, "sos_muted", JSON.stringify(mutedIds));
      siren.stop();
      renderBanner();
    } else {
      mutedIds = [];
      soundOn = true;
      writeValue(localStorage, "sos_sound", "on");
      writeValue(sessionStorage, "sos_muted", "[]");
      syncSoundSwitch();
      tryStart();
    }
  });

  // Browsers need a tap before they allow sound. Use the first tap anywhere.
  ["pointerdown", "keydown"].forEach(function (evt) {
    document.addEventListener(evt, function () {
      if (lastFeed && shouldSound(lastFeed) && !siren.isPlaying()) tryStart();
    }, { passive: true });
  });

  // ---- console-only controls ---------------------------------------------
  function syncSoundSwitch() {
    if (!soundSwitch) return;
    soundSwitch.textContent = soundOn ? "\uD83D\uDD14 Alarm sound: ON" : "\uD83D\uDD15 Alarm sound: OFF";
  }
  if (soundSwitch) {
    syncSoundSwitch();
    soundSwitch.addEventListener("click", function () {
      soundOn = !soundOn;
      writeValue(localStorage, "sos_sound", soundOn ? "on" : "off");
      syncSoundSwitch();
      if (lastFeed) applyFeed(lastFeed);
    });
  }
  if (testBtn) {
    testBtn.addEventListener("click", function () {
      if (siren.isPlaying()) return;
      siren.start().then(function (ok) {
        testBtn.textContent = ok ? "\uD83D\uDD0A Playing test\u2026" : "\u26A0 Sound blocked by browser";
        if (!ok) return;
        testTimer = setTimeout(function () {
          testTimer = null;
          if (!(lastFeed && shouldSound(lastFeed))) siren.stop();
          testBtn.textContent = "\uD83D\uDD14 Test alarm sound";
        }, 3500);
      });
    });
  }

  // ---- live "updated Xs ago" labels ---------------------------------------
  function updateAgoTimestamps(feed) {
    feed.alerts.forEach(function (a) {
      var nodes = document.querySelectorAll('[data-ago-for="' + a.id + '"]');
      for (var i = 0; i < nodes.length; i++) {
        if (a.updated_at) nodes[i].dataset.ts = a.updated_at;
      }
    });
    renderAgo();
  }

  function renderAgo() {
    var nodes = document.querySelectorAll(".js-ago");
    var now = Date.now();
    for (var i = 0; i < nodes.length; i++) {
      var ts = Date.parse(nodes[i].dataset.ts || "");
      if (isNaN(ts)) continue;
      var secs = Math.max(0, Math.round((now - ts) / 1000));
      var text = secs < 5 ? "just now" : secs < 60 ? secs + "s ago" : Math.round(secs / 60) + " min ago";
      nodes[i].textContent = text;
      // no update for a while -> warn that the phone may have lost GPS or signal
      nodes[i].classList.toggle("text-amber-600", secs > 45);
      nodes[i].classList.toggle("font-semibold", secs > 45);
    }
  }
  setInterval(renderAgo, 1000);

  // ---- redraw the console when alerts / positions change -------------------
  function maybeRedrawConsole(feed) {
    if (!root || refreshing || root.dataset.signature === feed.signature) return;
    refreshing = true;
    fetch(window.location.pathname + window.location.search, {
      credentials: "same-origin",
      headers: { "X-Requested-With": "fetch" }
    })
      .then(function (r) { return r.text(); })
      .then(function (html) {
        var doc = new DOMParser().parseFromString(html, "text/html");
        var fresh = doc.getElementById("alerts-root");
        if (fresh) {
          root.innerHTML = fresh.innerHTML;
          root.dataset.signature = feed.signature;
          updateAgoTimestamps(feed);
        }
      })
      .catch(function () { /* try again on the next poll */ })
      .then(function () { refreshing = false; });
  }

  // ---- polling ------------------------------------------------------------
  function poll() {
    fetch("/sos/feed", { credentials: "same-origin", headers: { "Accept": "application/json" } })
      .then(function (r) {
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(applyFeed)
      .catch(function () { /* logged out or offline: just try again */ })
      .then(function () { setTimeout(poll, POLL_MS); });
  }

  renderAgo();
  poll();
})();
